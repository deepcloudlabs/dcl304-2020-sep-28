class Move {
    constructor(guess, evaluation) {
        this.guess = guess;
        this.evaluation = evaluation;
    }
}